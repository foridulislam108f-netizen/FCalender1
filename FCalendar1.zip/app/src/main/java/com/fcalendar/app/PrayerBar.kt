package com.fcalendar.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.widget.RemoteViews
import androidx.core.app.ServiceCompat
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * নোটিফিকেশন প্যানেলে সবসময় থাকা নামাজের সময়সূচি (৫ ওয়াক্তের নাম + সময়, বর্তমান ওয়াক্ত হাইলাইট)।
 * সময় আসে PrayerTimes থেকে — উইজেটে যা দেখায় হুবহু সেটাই।
 */
object PrayerBar {

    const val CHANNEL = "prayer_bar"
    const val NOTIF_ID = 5001
    const val ACTION_UPDATE = "com.fcalendar.app.PRAYER_BAR_UPDATE"
    const val ACTION_DELETED = "com.fcalendar.app.PRAYER_BAR_DELETED"

    private val NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "ঈশা")
    private val BOX = intArrayOf(R.id.bar_fajr_box, R.id.bar_dhuhr_box, R.id.bar_asr_box, R.id.bar_maghrib_box, R.id.bar_isha_box)
    private val NAME = intArrayOf(R.id.bar_fajr_name, R.id.bar_dhuhr_name, R.id.bar_asr_name, R.id.bar_maghrib_name, R.id.bar_isha_name)
    private val TIME = intArrayOf(R.id.bar_fajr_time, R.id.bar_dhuhr_time, R.id.bar_asr_time, R.id.bar_maghrib_time, R.id.bar_isha_time)

    private const val PREFS = "prayer_bar"
    private const val KEY_ON = "on"

    /** ডিফল্ট: চালু */
    fun isEnabled(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ON, true)

    fun setEnabled(context: Context, on: Boolean) {
        val ctx = context.applicationContext
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ON, on).apply()
        if (on) {
            start(ctx)
        } else {
            try { ctx.stopService(Intent(ctx, PrayerBarService::class.java)) } catch (_: Exception) { }
            cancelAll(ctx)
        }
    }

    private fun cancelAll(ctx: Context) {
        try { ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) } catch (_: Exception) { }
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(PendingIntent.getBroadcast(
                ctx, 83, Intent(ctx, PrayerBarReceiver::class.java).setAction(ACTION_UPDATE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ))
        } catch (_: Exception) { }
    }

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "নামাজের সময়সূচি (স্থায়ী)", NotificationManager.IMPORTANCE_LOW)
            ch.description = "নোটিফিকেশন প্যানেলে ৫ ওয়াক্তের সময় সবসময় দেখায়"
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun zone(ctx: Context): ZoneId = try {
        ZoneId.of(PrayerTimes.getTzId(ctx))
    } catch (e: Exception) {
        ZoneId.of(PrayerTimes.DEFAULT_TZ_ID)
    }

    private fun bn(n: Int) = CalendarWidget.bnNum(n)

    private fun clock(totalMin: Int): String {
        val hh = (totalMin / 60) % 12
        val h12 = if (hh == 0) 12 else hh
        val mm = totalMin % 60
        return bn(h12) + ":" + (if (mm < 10) "০" else "") + bn(mm)
    }

    private fun bold(s: String): CharSequence {
        val sp = SpannableString(s)
        sp.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sp
    }

    fun build(ctx: Context): Notification {
        ensureChannel(ctx)
        val z = zone(ctx)
        val now = ZonedDateTime.now(z)
        val today = now.toLocalDate()
        val start = today.atStartOfDay(z)
        val mins = PrayerTimes.minutes(ctx, today)

        // উইজেটের মতোই: যে ওয়াক্ত শুরু হয়ে গেছে তার শেষটাই বর্তমান
        var current = 4
        for (i in 0..4) if (!now.isBefore(start.plusMinutes(mins[i].toLong()))) current = i

        val v = RemoteViews(ctx.packageName, R.layout.notif_prayer_bar)
        for (i in 0..4) {
            val hl = i == current
            v.setTextViewText(NAME[i], if (hl) bold(NAMES[i]) else NAMES[i])
            v.setTextViewText(TIME[i], if (hl) bold(clock(mins[i])) else clock(mins[i]))
            v.setInt(BOX[i], "setBackgroundResource", if (hl) R.drawable.bar_cell_on else R.drawable.bar_cell_off)
            val c = if (hl) 0xFF1A1A28.toInt() else 0
            if (hl) {
                v.setTextColor(NAME[i], c)
                v.setTextColor(TIME[i], c)
            } else {
                // সিস্টেমের লাইট/ডার্ক থিম অনুযায়ী ডিফল্ট রঙ
                v.setTextColor(NAME[i], themeText(ctx))
                v.setTextColor(TIME[i], themeText(ctx))
            }
        }

        val open = PendingIntent.getActivity(
            ctx, 81, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val del = PendingIntent.getBroadcast(
            ctx, 82, Intent(ctx, PrayerBarReceiver::class.java).setAction(ACTION_DELETED),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_prayer)
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(v)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setLocalOnly(true)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setDeleteIntent(del)
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    /** ডার্ক মোডে সাদা, লাইট মোডে কালো */
    private fun themeText(ctx: Context): Int {
        val night = (ctx.resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        return if (night) 0xFFF5F4FC.toInt() else 0xFF1A1A28.toInt()
    }

    /** নোটিফিকেশন আপডেট + পরের পরিবর্তনের অ্যালার্ম */
    fun refresh(context: Context) {
        val ctx = context.applicationContext
        if (!isEnabled(ctx)) { cancelAll(ctx); return }
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(ctx))
        } catch (_: Exception) { }
        scheduleNext(ctx)
    }

    private fun scheduleNext(ctx: Context) {
        val z = zone(ctx)
        val now = ZonedDateTime.now(z)
        val today = now.toLocalDate()
        val start = today.atStartOfDay(z)
        val mins = PrayerTimes.minutes(ctx, today)
        var at: ZonedDateTime = today.plusDays(1).atStartOfDay(z).plusSeconds(3)
        for (i in 0..4) {
            val t = start.plusMinutes(mins[i].toLong()).plusSeconds(1)
            if (t.isAfter(now)) { if (t.isBefore(at)) at = t; break }
        }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, 83, Intent(ctx, PrayerBarReceiver::class.java).setAction(ACTION_UPDATE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val ms = at.toInstant().toEpochMilli()
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            }
        } catch (_: Exception) { }
    }

    /** সার্ভিস চালু করে (ফোরগ্রাউন্ড সার্ভিস থাকলে সিস্টেম নোটিফিকেশনটা সহজে মুছতে দেয় না) */
    fun start(context: Context) {
        val ctx = context.applicationContext
        if (!isEnabled(ctx)) return
        try {
            ctx.startForegroundService(Intent(ctx, PrayerBarService::class.java))
        } catch (_: Exception) {
            // ব্যাকগ্রাউন্ড থেকে সার্ভিস চালু করা না গেলে সাধারণ স্থায়ী নোটিফিকেশন
            refresh(ctx)
        }
    }
}

class PrayerBarService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!PrayerBar.isEnabled(this)) {
            // startForegroundService() এর পর অবশ্যই startForeground() ডাকতে হয়, তাই আগে ডেকে তারপর বন্ধ করি
            try { startForeground(PrayerBar.NOTIF_ID, PrayerBar.build(this)) } catch (_: Exception) { }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val n = PrayerBar.build(this)
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, PrayerBar.NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(PrayerBar.NOTIF_ID, n)
            }
        } catch (_: Exception) { }
        PrayerBar.refresh(this)
        return START_STICKY
    }
}

/** সময় হলে / রিবুট / সময় বদলালে / আপডেটের পর নোটিফিকেশন নতুন করে বসায় */
class PrayerBarReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> PrayerBar.start(ctx)
            else -> PrayerBar.refresh(ctx)
        }
    }
}
