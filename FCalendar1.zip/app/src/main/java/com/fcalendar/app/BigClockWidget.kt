package com.fcalendar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/** "বড় ঘড়ি" উইজেট (৪×২): বোল্ড বড় সময় + AM/PM + তারিখ + উপরের ডান কর্নারে সেলসিয়াস তাপমাত্রা */
class BigClockWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        update(ctx, mgr, ids)
        Salat2Widget.fetchTempIfStale(ctx, goAsync())
    }

    override fun onEnabled(ctx: Context) {
        Salat2Widget.fetchTempIfStale(ctx)
    }

    companion object {
        private fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val v = RemoteViews(ctx.packageName, R.layout.widget_bigclock)
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.bigclock_root, open)
            val temp = Salat2Widget.cachedTemp(ctx)
            if (temp != null) {
                v.setTextViewText(R.id.bigclock_temp, temp.toString() + "°")
                v.setViewVisibility(R.id.bigclock_temp, View.VISIBLE)
            } else {
                v.setViewVisibility(R.id.bigclock_temp, View.GONE)
            }
            for (id in ids) mgr.updateAppWidget(id, v)
        }

        /** তাপমাত্রা নতুন এলে সব "বড় ঘড়ি" উইজেটে বসায় */
        fun refreshAll(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, BigClockWidget::class.java))
            if (ids.isNotEmpty()) update(app, mgr, ids)
        }
    }
}
