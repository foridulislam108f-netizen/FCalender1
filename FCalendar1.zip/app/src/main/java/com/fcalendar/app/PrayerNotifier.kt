package com.fcalendar.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.app.Notification
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * প্রতিটি ওয়াক্ত শুরুর ঠিক সময়ে নোটিফিকেশন + পছন্দের শব্দ।
 * সময় আসে PrayerTimes থেকে (উইজেটে যে সময় দেখায় সেটাই)।
 */
object PrayerNotifier {

    private const val PREFS = "prayer_notify"
    private const val KEY_ON = "on"
    private const val KEY_SOUND = "sound"
    private const val CH_PREFIX = "prayer_ch_"
    private const val REQ_ALARM = 71

    const val ACTION_ALARM = "com.fcalendar.app.PRAYER_ALARM"
    const val DEFAULT_SOUND = "bell"

    private val NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "ঈশা")

    class Sound(val id: String, val bn: String, val en: String, val raw: Int?)

    val SOUNDS = listOf(
        Sound("bell", "ঘণ্টা", "Bell", R.raw.prayer_bell),
        Sound("chime", "চাইম", "Chime", R.raw.prayer_chime),
        Sound("soft", "নরম সুর", "Soft tone", R.raw.prayer_soft),
        Sound("harp", "বীণা", "Harp", R.raw.prayer_harp),
        Sound("beep", "বিপ বিপ", "Beep", R.raw.prayer_beep),
        Sound("call", "দীর্ঘ সুর", "Long tune", R.raw.prayer_call),
        Sound("system", "ফোনের ডিফল্ট নোটিফিকেশন শব্দ", "Phone default notification", null),
        Sound("alarm", "ফোনের অ্যালার্ম শব্দ", "Phone alarm sound", null),
        Sound("silent", "শব্দ ছাড়া (শুধু ভাইব্রেশন)", "Silent (vibrate only)", null)
    )

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ON, false)

    fun setEnabled(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_ON, on).apply()
        if (on) ensureChannel(ctx.applicationContext, soundOf(getSoundId(ctx)))
        schedule(ctx)
    }

    fun getSoundId(ctx: Context): String {
        val id = prefs(ctx).getString(KEY_SOUND, DEFAULT_SOUND) ?: DEFAULT_SOUND
        return if (SOUNDS.any { it.id == id }) id else DEFAULT_SOUND
    }

    fun setSoundId(ctx: Context, id: String) {
        if (SOUNDS.none { it.id == id }) return
        prefs(ctx).edit().putString(KEY_SOUND, id).apply()
        ensureChannel(ctx.applicationContext, soundOf(id))
    }

    private fun soundOf(id: String): Sound = SOUNDS.firstOrNull { it.id == id } ?: SOUNDS[0]

    private fun soundUri(ctx: Context, s: Sound): Uri? = when {
        s.raw != null -> Uri.parse("android.resource://${ctx.packageName}/${s.raw}")
        s.id == "system" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        s.id == "alarm" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        else -> null
    }

    /** অ্যান্ড্রয়েডে চ্যানেল তৈরির পর শব্দ বদলানো যায় না; তাই প্রতিটি শব্দের আলাদা চ্যানেল, পুরনোগুলো মুছে ফেলা হয় */
    private fun ensureChannel(ctx: Context, s: Sound): String {
        val id = CH_PREFIX + s.id
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "নামাজের ওয়াক্ত", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "প্রতিটি ওয়াক্ত শুরুর সময়ে নোটিফিকেশন"
            ch.enableVibration(true)
            val uri = soundUri(ctx, s)
            if (uri != null) {
                ch.setSound(
                    uri,
                    AudioAttributes.Builder()
                        .setUsage(if (s.id == "alarm") AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            } else {
                ch.setSound(null, null)
            }
            nm.createNotificationChannel(ch)
        }
        for (c in nm.notificationChannels) {
            if (c.id.startsWith(CH_PREFIX) && c.id != id) nm.deleteNotificationChannel(c.id)
        }
        return id
    }

    fun notificationsAllowed(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    private fun zone(ctx: Context): ZoneId = try {
        ZoneId.of(PrayerTimes.getTzId(ctx))
    } catch (e: Exception) {
        ZoneId.of(PrayerTimes.DEFAULT_TZ_ID)
    }

    private fun alarmIntent(ctx: Context, idx: Int, at: Long): PendingIntent {
        val i = Intent(ctx, PrayerAlarmReceiver::class.java).setAction(ACTION_ALARM)
            .putExtra("idx", idx).putExtra("at", at)
        return PendingIntent.getBroadcast(ctx, REQ_ALARM, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** পরের ওয়াক্তের শুরুর সময়ের জন্য ঠিক-সময়ের অ্যালার্ম বসায় (বন্ধ থাকলে বাতিল করে) */
    fun schedule(context: Context) {
        val ctx = context.applicationContext
        PrayerBar.refresh(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!isEnabled(ctx)) {
            am.cancel(alarmIntent(ctx, 0, 0L))
            return
        }
        val z = zone(ctx)
        val now = ZonedDateTime.now(z)
        var idx = -1
        var at: ZonedDateTime? = null
        loop@ for (d in 0..1) {
            val date = now.toLocalDate().plusDays(d.toLong())
            val mins = PrayerTimes.minutes(ctx, date)
            val start = date.atStartOfDay(z)
            for (i in 0..4) {
                val t = start.plusMinutes(mins[i].toLong())
                if (t.isAfter(now)) { idx = i; at = t; break@loop }
            }
        }
        if (at == null) return
        val ms = at.toInstant().toEpochMilli()
        val pi = alarmIntent(ctx, idx, ms)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }

    private fun bn(n: Int) = CalendarWidget.bnNum(n)

    private fun clockText(ctx: Context, atMs: Long): String {
        val t = Instant.ofEpochMilli(atMs).atZone(zone(ctx))
        val h = t.hour % 12
        val h12 = if (h == 0) 12 else h
        val m = t.minute
        return bn(h12) + ":" + (if (m < 10) "০" else "") + bn(m)
    }

    /** ওয়াক্ত শুরুর নোটিফিকেশন */
    fun show(context: Context, idx: Int, atMs: Long) {
        val ctx = context.applicationContext
        val city = PrayerTimes.getCity(ctx)
        post(ctx, 5100 + idx, NAMES[idx] + "-এর ওয়াক্ত শুরু হয়েছে", clockText(ctx, atMs) + " · " + city)
    }

    /** সেটিংসের "পরীক্ষা করুন" বাটন */
    fun test(context: Context) {
        val ctx = context.applicationContext
        post(ctx, 5199, "নামাজের নোটিফিকেশন পরীক্ষা", "এই শব্দটাই ওয়াক্ত শুরুতে বাজবে")
    }

    private fun post(ctx: Context, id: Int, title: String, text: String) {
        val chId = ensureChannel(ctx, soundOf(getSoundId(ctx)))
        val open = PendingIntent.getActivity(
            ctx, 72, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, chId)
            .setSmallIcon(R.drawable.ic_notif_prayer)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (_: Exception) { }
    }

    // ---------- শব্দ শোনা (সেটিংসে বাছাইয়ের সময়) ----------
    private var player: MediaPlayer? = null
    private var ringtone: Ringtone? = null

    fun stopPreview() {
        try { player?.release() } catch (_: Exception) { }
        player = null
        try { ringtone?.stop() } catch (_: Exception) { }
        ringtone = null
    }

    fun preview(context: Context, id: String) {
        val ctx = context.applicationContext
        stopPreview()
        val s = soundOf(id)
        try {
            if (s.raw != null) {
                val mp = MediaPlayer.create(ctx, s.raw) ?: return
                mp.setOnCompletionListener { it.release(); if (player === it) player = null }
                player = mp
                mp.start()
            } else {
                val uri = soundUri(ctx, s) ?: return
                val r = RingtoneManager.getRingtone(ctx, uri) ?: return
                ringtone = r
                r.play()
            }
        } catch (_: Exception) { }
    }
}

/** অ্যালার্ম/রিবুট/সময় বদলালে ওয়াক্তের নোটিফিকেশন আবার বসায় */
class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == PrayerNotifier.ACTION_ALARM) {
            val idx = intent.getIntExtra("idx", -1)
            val at = intent.getLongExtra("at", 0L)
            // ফোন বন্ধ/ঘুমে থেকে অনেক দেরিতে জাগলে (১০ মিনিটের বেশি) পুরনো নোটিফিকেশন দেখাই না
            if (idx in 0..4 && PrayerNotifier.isEnabled(ctx) &&
                System.currentTimeMillis() - at < 10 * 60 * 1000L) {
                PrayerNotifier.show(ctx, idx, at)
            }
        }
        PrayerNotifier.schedule(ctx)
    }
}
