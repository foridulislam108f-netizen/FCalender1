package com.fcalendar.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import android.widget.RemoteViews
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** নামাজের সময়সূচির উইজেট */
class PrayerWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        refresh(ctx, mgr, ids)
    }

    override fun onEnabled(ctx: Context) {
        refreshAll(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_UPDATE,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> refreshAll(ctx)
            ACTION_LOCATION -> {
                // লোকেশন সেটিংস বা অ্যাপে নিয়ে যাওয়া
                val open = Intent(ctx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("request_location", true)
                }
                ctx.startActivity(open)
            }
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.fcalendar.app.PRAYER_UPDATE"
        const val ACTION_LOCATION = "com.fcalendar.app.PRAYER_LOCATION"

        private val KEYS = arrayOf("fajr", "dhuhr", "asr", "maghrib", "isha")
        private val NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "ঈশা")
        private val WEEK = arrayOf(
            "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
        )
        private val GM = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val HM = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )

        private val IDS_BOX = intArrayOf(
            R.id.pr_fajr_box, R.id.pr_dhuhr_box, R.id.pr_asr_box, R.id.pr_maghrib_box, R.id.pr_isha_box
        )
        private val IDS_NAME = intArrayOf(
            R.id.pr_fajr_name, R.id.pr_dhuhr_name, R.id.pr_asr_name, R.id.pr_maghrib_name, R.id.pr_isha_name
        )
        private val IDS_TIME = intArrayOf(
            R.id.pr_fajr_time, R.id.pr_dhuhr_time, R.id.pr_asr_time, R.id.pr_maghrib_time, R.id.pr_isha_time
        )

        // countdown color options
        private val COUNT_COLORS = mapOf(
            "default" to 0xFFECEBF5.toInt(),
            "gold" to 0xFFE8C97A.toInt(),
            "green" to 0xFF8FD19E.toInt(),
            "cyan" to 0xFF7AD4E8.toInt(),
            "pink" to 0xFFE8A0C0.toInt(),
            "white" to 0xFFFFFFFF.toInt()
        )

        fun refreshAll(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, PrayerWidget::class.java))
            if (ids.isNotEmpty()) refresh(app, mgr, ids)
        }

        private fun refresh(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val zone = try {
                ZoneId.of(PrayerTimes.getTzId(ctx))
            } catch (e: Exception) {
                ZoneId.of(PrayerTimes.DEFAULT_TZ_ID)
            }
            val now = ZonedDateTime.now(zone)
            val today = now.toLocalDate()
            val start = today.atStartOfDay(zone)

            val todayMin = PrayerTimes.minutes(ctx, today)
            val tomorrowMin = PrayerTimes.minutes(ctx, today.plusDays(1))
            val todayTimes = Array(5) { start.plusMinutes(todayMin[it].toLong()) }
            val nextFajr = today.plusDays(1).atStartOfDay(zone).plusMinutes(tomorrowMin[0].toLong())

            var current = 4
            for (i in 0..4) if (!now.isBefore(todayTimes[i])) current = i
            var nextIdx = -1
            for (i in 0..4) if (now.isBefore(todayTimes[i])) { nextIdx = i; break }
            val nextTime = if (nextIdx >= 0) todayTimes[nextIdx] else nextFajr
            val nextName = if (nextIdx >= 0) NAMES[nextIdx] else NAMES[0]

            val v = RemoteViews(ctx.packageName, R.layout.widget_prayer)

            // background color for whole widget (simple tint via root if possible; keep default drawable for now)
            // For full bg change we'd need more drawables; keep structure.

            val dow = now.dayOfWeek.value % 7
            v.setTextViewText(
                R.id.pr_date,
                WEEK[dow] + ", " + bn(today.dayOfMonth) + " " + GM[today.monthValue - 1]
            )
            val h = HijrahDate.from(today)
            v.setTextViewText(
                R.id.pr_hijri,
                bn(h.get(ChronoField.DAY_OF_MONTH)) + " " + HM[h.get(ChronoField.MONTH_OF_YEAR) - 1]
            )
            v.setTextViewText(R.id.pr_city, PrayerTimes.getCity(ctx))

            for (i in 0..4) {
                v.setTextViewText(IDS_NAME[i], NAMES[i])
                v.setTextViewText(IDS_TIME[i], clock(todayMin[i]))
                val hl = i == current
                val bg = when {
                    !hl -> R.drawable.prayer_cell_none
                    i == 0 -> R.drawable.prayer_cell_first
                    i == 4 -> R.drawable.prayer_cell_last
                    else -> R.drawable.prayer_cell_mid
                }
                v.setInt(IDS_BOX[i], "setBackgroundResource", bg)
                // বোল্ড + হালকা উজ্জ্বল রঙ (নাম ও সময় দুটোই)
                val txt = if (hl) 0xFF1A1A28.toInt() else 0xFFF5F4FC.toInt()
                v.setTextColor(IDS_NAME[i], txt)
                v.setTextColor(IDS_TIME[i], txt)
                // RemoteViews-এ টেক্সট স্টাইল বোল্ড নিশ্চিত
                try {
                    v.setTextViewTextSize(IDS_NAME[i], android.util.TypedValue.COMPLEX_UNIT_SP, 13.5f)
                    v.setTextViewTextSize(IDS_TIME[i], android.util.TypedValue.COMPLEX_UNIT_SP, 14.5f)
                } catch (_: Exception) {}
            }

            val remain = nextTime.toInstant().toEpochMilli() - now.toInstant().toEpochMilli()
            v.setChronometerCountDown(R.id.pr_countdown, true)
            v.setChronometer(
                R.id.pr_countdown,
                SystemClock.elapsedRealtime() + remain,
                "$nextName. %s",
                true
            )
            val countColor = COUNT_COLORS[PrayerTimes.getCountColor(ctx)] ?: COUNT_COLORS["default"]!!
            v.setTextColor(R.id.pr_countdown, countColor)

            val open = PendingIntent.getActivity(
                ctx, 2, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.prayer_root, open)

            // লোকেশন আইকন চাপলে লোকেশন রিকোয়েস্ট
            val locIntent = Intent(ctx, PrayerWidget::class.java).setAction(ACTION_LOCATION)
            val locPi = PendingIntent.getBroadcast(
                ctx, 4, locIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // pin is ImageView without id in layout — make city row clickable instead via pr_city parent? 
            // We give pr_city a click, and also root already opens app.
            // For pin specifically, we can set on the city TextView.
            v.setOnClickPendingIntent(R.id.pr_location_pin, locPi)
            v.setOnClickPendingIntent(R.id.pr_city, locPi)

            for (id in ids) mgr.updateAppWidget(id, v)

            val midnight = today.plusDays(1).atStartOfDay(zone).plusSeconds(5)
            val trigger = if (nextTime.isBefore(midnight)) nextTime.plusSeconds(2) else midnight
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 3, Intent(ctx, PrayerWidget::class.java).setAction(ACTION_UPDATE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.toInstant().toEpochMilli(), pi)
        }

        private fun bn(n: Int): String = CalendarWidget.bnNum(n)

        private fun clock(totalMin: Int): String {
            val hh = (totalMin / 60) % 12
            val h12 = if (hh == 0) 12 else hh
            val mm = totalMin % 60
            return bn(h12) + ":" + (if (mm < 10) "০" else "") + bn(mm)
        }
    }
}
