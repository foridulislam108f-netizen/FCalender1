package com.fcalendar.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** নামাজের সময়সূচির উইজেট (আগের CalendarWidget অপরিবর্তিত থাকে) */
class PrayerWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        refresh(ctx, mgr, ids)
    }

    override fun onEnabled(ctx: Context) {
        refreshAll(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_UPDATE,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> refreshAll(ctx)
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.fcalendar.app.PRAYER_UPDATE"

        private val KEYS = arrayOf("fajr", "dhuhr", "asr", "maghrib", "isha")
        private val NAMES = arrayOf("ফজর", "যোহর", "আসর", "মাগরিব", "ঈশা")
        private val WEEK = arrayOf(
            "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
        )
        private val GM = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val HM = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )

        private val IDS_BOX = intArrayOf(
            R.id.pr_fajr_box, R.id.pr_dhuhr_box, R.id.pr_asr_box, R.id.pr_maghrib_box, R.id.pr_isha_box
        )
        private val IDS_NAME = intArrayOf(
            R.id.pr_fajr_name, R.id.pr_dhuhr_name, R.id.pr_asr_name, R.id.pr_maghrib_name, R.id.pr_isha_name
        )
        private val IDS_TIME = intArrayOf(
            R.id.pr_fajr_time, R.id.pr_dhuhr_time, R.id.pr_asr_time, R.id.pr_maghrib_time, R.id.pr_isha_time
        )

        fun refreshAll(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, PrayerWidget::class.java))
            if (ids.isNotEmpty()) refresh(app, mgr, ids)
        }

        private fun refresh(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val zone = ZoneId.of(PrayerTimes.TZ_ID)
            val now = ZonedDateTime.now(zone)
            val today = now.toLocalDate()
            val start = today.atStartOfDay(zone)

            val todayMin = PrayerTimes.minutes(today)
            val tomorrowMin = PrayerTimes.minutes(today.plusDays(1))
            val todayTimes = Array(5) { start.plusMinutes(todayMin[it].toLong()) }
            val nextFajr = today.plusDays(1).atStartOfDay(zone).plusMinutes(tomorrowMin[0].toLong())

            // চলমান ওয়াক্ত = সর্বশেষ পার হওয়া ওয়াক্ত (ফজরের আগে হলে আগের রাতের ঈশা)
            var current = 4
            for (i in 0..4) if (!now.isBefore(todayTimes[i])) current = i
            // পরের ওয়াক্ত
            var nextIdx = -1
            for (i in 0..4) if (now.isBefore(todayTimes[i])) { nextIdx = i; break }
            val nextTime = if (nextIdx >= 0) todayTimes[nextIdx] else nextFajr
            val nextName = if (nextIdx >= 0) NAMES[nextIdx] else NAMES[0]

            val v = RemoteViews(ctx.packageName, R.layout.widget_prayer)

            val dow = now.dayOfWeek.value % 7 // রবি=0
            v.setTextViewText(
                R.id.pr_date,
                WEEK[dow] + ", " + bn(today.dayOfMonth) + " " + GM[today.monthValue - 1]
            )
            val h = HijrahDate.from(today)
            v.setTextViewText(
                R.id.pr_hijri,
                bn(h.get(ChronoField.DAY_OF_MONTH)) + " " + HM[h.get(ChronoField.MONTH_OF_YEAR) - 1]
            )
            v.setTextViewText(R.id.pr_city, PrayerTimes.CITY)

            for (i in 0..4) {
                v.setTextViewText(IDS_NAME[i], NAMES[i])
                v.setTextViewText(IDS_TIME[i], clock(todayMin[i]))
                val hl = i == current
                val bg = when {
                    !hl -> R.drawable.prayer_cell_none
                    i == 0 -> R.drawable.prayer_cell_first
                    i == 4 -> R.drawable.prayer_cell_last
                    else -> R.drawable.prayer_cell_mid
                }
                v.setInt(IDS_BOX[i], "setBackgroundResource", bg)
                val txt = if (hl) 0xFF1E1E2C.toInt() else 0xFFECEBF5.toInt()
                v.setTextColor(IDS_NAME[i], txt)
                v.setTextColor(IDS_TIME[i], txt)
            }

            // কাউন্টডাউন (প্রতি সেকেন্ড সিস্টেম নিজেই চালায়)
            val remain = nextTime.toInstant().toEpochMilli() - now.toInstant().toEpochMilli()
            v.setChronometerCountDown(R.id.pr_countdown, true)
            v.setChronometer(
                R.id.pr_countdown,
                SystemClock.elapsedRealtime() + remain,
                "$nextName. %s",
                true
            )

            val open = PendingIntent.getActivity(
                ctx, 2, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.prayer_root, open)

            for (id in ids) mgr.updateAppWidget(id, v)

            // পরের ওয়াক্তে (বা মধ্যরাতে) আবার আপডেট
            val midnight = today.plusDays(1).atStartOfDay(zone).plusSeconds(5)
            val trigger = if (nextTime.isBefore(midnight)) nextTime.plusSeconds(2) else midnight
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 3, Intent(ctx, PrayerWidget::class.java).setAction(ACTION_UPDATE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.toInstant().toEpochMilli(), pi)
        }

        private fun bn(n: Int): String = CalendarWidget.bnNum(n)

        /** মিনিট -> ১২ ঘণ্টার বাংলা সময়, যেমন ৪:৪৯ */
        private fun clock(totalMin: Int): String {
            val hh = (totalMin / 60) % 12
            val h12 = if (hh == 0) 12 else hh
            val mm = totalMin % 60
            return bn(h12) + ":" + (if (mm < 10) "০" else "") + bn(mm)
        }
    }
}
