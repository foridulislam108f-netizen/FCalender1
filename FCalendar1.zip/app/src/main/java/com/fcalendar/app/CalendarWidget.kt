package com.fcalendar.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar
import java.util.GregorianCalendar

class CalendarWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        update(ctx, mgr, ids)
        scheduleMidnight(ctx)
    }

    override fun onEnabled(ctx: Context) {
        scheduleMidnight(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_MIDNIGHT,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, CalendarWidget::class.java))
                update(ctx, mgr, ids)
                scheduleMidnight(ctx)
            }
        }
    }

    private fun buildViews(ctx: Context): RemoteViews {
        val now = Calendar.getInstance()
        val bn = toBengali(now)
        val v = RemoteViews(ctx.packageName, R.layout.widget_calendar)
        // সেটিংস থেকে বাছাই করা রঙ
        v.setInt(R.id.widget_root, "setBackgroundResource", WidgetColors.background(ctx))

        v.setTextViewText(
            R.id.widget_bn_date,
            bnNum(bn[2]) + " " + BM_BN[bn[1]] + " " + bnNum(bn[0])
        )

        val dayNum = now.get(Calendar.DAY_OF_MONTH)
        val dd = if (dayNum < 10) "০" + bnNum(dayNum) else bnNum(dayNum)
        v.setTextViewText(
            R.id.widget_full_date,
            WDF_BN[now.get(Calendar.DAY_OF_WEEK) - 1] + ", " + dd + " " +
                GM_BN[now.get(Calendar.MONTH)] + " " + bnNum(now.get(Calendar.YEAR))
        )

        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        v.setOnClickPendingIntent(R.id.widget_root, open)
        return v
    }

    private fun scheduleMidnight(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 5)
        c.set(Calendar.MILLISECOND, 0)
        val i = Intent(ctx, CalendarWidget::class.java).setAction(ACTION_MIDNIGHT)
        val pi = PendingIntent.getBroadcast(
            ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.set(AlarmManager.RTC, c.timeInMillis, pi)
    }

    companion object {
        /** সব উইজেটে বর্তমান রঙ ও তারিখ বসায় (সেটিংস থেকেও এটি ডাকা হয়) */
        fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val views = CalendarWidget().buildViews(ctx)
            for (id in ids) mgr.updateAppWidget(id, views)
        }

        const val ACTION_MIDNIGHT = "com.fcalendar.app.MIDNIGHT_UPDATE"

        private val BN_LEN = intArrayOf(31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 30, 30)
        private val DIGITS = arrayOf("০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯")
        private val GM_BN = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val BM_BN = arrayOf(
            "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
            "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
        )
        private val WDF_BN = arrayOf(
            "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
        )

        fun bnNum(n: Int): String {
            val sb = StringBuilder()
            for (ch in n.toString()) sb.append(DIGITS[ch - '0'])
            return sb.toString()
        }

        private fun monthLen(startYear: Int, idx: Int): Int {
            if (idx == 10) {
                val leap = GregorianCalendar(startYear + 1, 1, 29).get(Calendar.DAY_OF_MONTH) == 29
                return if (leap) 31 else 30
            }
            return BN_LEN[idx]
        }

        /** Gregorian -> [bengaliYear, monthIndex, day]. অ্যাপের হিসাবের সাথে হুবহু এক (১ বৈশাখ = ১৫ এপ্রিল) */
        fun toBengali(date: Calendar): IntArray {
            val y = date.get(Calendar.YEAR)
            val m = date.get(Calendar.MONTH)
            val d = date.get(Calendar.DAY_OF_MONTH)
            val startYear = if (m > 3 || (m == 3 && d >= 15)) y else y - 1
            val start = GregorianCalendar(startYear, 3, 15)
            val today = GregorianCalendar(y, m, d)
            var rem = Math.round((today.timeInMillis - start.timeInMillis) / 86400000.0).toInt()
            var idx = 0
            while (rem >= monthLen(startYear, idx)) {
                rem -= monthLen(startYear, idx)
                idx++
            }
            return intArrayOf(startYear - 593, idx, rem + 1)
        }
    }
}
