package com.fcalendar.app

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ServiceCompat

/**
 * ওয়াক্তের শব্দ (ঘণ্টা/আজান/ইকামাত) নিজে বাজায়, যাতে অন্য অ্যাপের নোটিফিকেশন এসে শব্দ কেটে না দেয়।
 * বাজার সময় অন্য শব্দ নিচু হয়ে যায়; শেষ হলে নোটিফিকেশন থেকে যায়।
 */
class PrayerSoundService : Service() {

    private var mp: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    private var nid = 5100
    private var title = ""
    private var text = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        nid = intent?.getIntExtra("nid", 5100) ?: 5100
        title = intent?.getStringExtra("title") ?: ""
        text = intent?.getStringExtra("text") ?: ""
        val raw = intent?.getIntExtra("raw", 0) ?: 0
        val n = PrayerNotifier.buildQuiet(this, title, text, false)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(nid, n)
            }
        } catch (_: Exception) {
            PrayerNotifier.postFallback(this, nid, title, text)
            stopSelf()
            return START_NOT_STICKY
        }
        if (raw == 0 || !play(raw)) finish()
        return START_NOT_STICKY
    }

    private fun play(raw: Int): Boolean {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs).build()
            focus = req
            am.requestAudioFocus(req)
            val p = MediaPlayer.create(this, raw) ?: return false
            p.setAudioAttributes(attrs)
            p.setOnCompletionListener { finish() }
            p.setOnErrorListener { _, _, _ -> finish(); true }
            mp = p
            p.start()
            handler.postDelayed({ finish() }, 3 * 60 * 1000L)
            return true
        } catch (_: Exception) {
            return false
        }
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focus?.let { am.abandonAudioFocusRequest(it) }
        } catch (_: Exception) {}
        focus = null
        try { stopForeground(STOP_FOREGROUND_DETACH) } catch (_: Exception) {}
        try {
            getSystemService(NotificationManager::class.java)
                .notify(nid, PrayerNotifier.buildQuiet(this, title, text, true))
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (_: Exception) {}
        mp = null
        super.onDestroy()
    }
}
