package com.fcalendar.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.content.BroadcastReceiver
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** "সালাত ৩" উইজেট (৪×২.৫): তারিখ, হিজরি তারিখ ও পাঁচ ওয়াক্ত নামাজের সময়সূচী */
class Salat3Widget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        refresh(ctx, mgr, ids)
        Salat2Widget.fetchTempIfStale(ctx, goAsync())
        UpdateChecker.checkIfDue(ctx)
    }

    override fun onEnabled(ctx: Context) {
        refreshAll(ctx)
        Salat2Widget.fetchTempIfStale(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_UPDATE,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                refreshAll(ctx)
                Salat2Widget.fetchTempIfStale(ctx, goAsync())
            }
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.fcalendar.app.SALAT3_UPDATE"

        // পাঁচ ওয়াক্ত: PrayerTimes-এর সূচক (০=ফজর, ১=জোহর, ২=আসর, ৩=মাগরিব, ৪=ইশা)
        private val SHOWN = intArrayOf(0, 1, 2, 3, 4)
        private val NAMES = arrayOf("ফজর", "জোহর", "আসর", "মাগরিব", "ইশা")

        private val IDS_BOX = intArrayOf(R.id.s3_box0, R.id.s3_box1, R.id.s3_box2, R.id.s3_box3, R.id.s3_box4)
        private val IDS_NAME = intArrayOf(R.id.s3_name0, R.id.s3_name1, R.id.s3_name2, R.id.s3_name3, R.id.s3_name4)
        private val IDS_TIME = intArrayOf(R.id.s3_time0, R.id.s3_time1, R.id.s3_time2, R.id.s3_time3, R.id.s3_time4)
        private val IDS_AMPM = intArrayOf(R.id.s3_ampm0, R.id.s3_ampm1, R.id.s3_ampm2, R.id.s3_ampm3, R.id.s3_ampm4)
        private val IDS_TAG = intArrayOf(R.id.s3_tag0, R.id.s3_tag1, R.id.s3_tag2, R.id.s3_tag3, R.id.s3_tag4)

        private val WEEK = arrayOf(
            "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
        )
        private val BM = arrayOf(
            "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
            "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
        )
        private val GM = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val HM = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )

        // প্রতিদিন একটি করে আমল (দিনের ক্রম অনুযায়ী ঘুরে ঘুরে আসে)
        private val AMAL = arrayOf(
            "সূরা আল-ফাতিহা তিলাওয়াত করুন",
            "সূরা ইখলাস তিলাওয়াত করুন",
            "আয়াতুল কুরসি পড়ুন",
            "ইস্তিগফার পড়ুন",
            "দরূদ শরীফ পড়ুন",
            "সকাল-সন্ধ্যার যিকির করুন",
            "কাউকে সালাম দিন",
            "ছোট কিছু দান করুন",
            "সূরা আল-মুলক তিলাওয়াত করুন",
            "চাশতের নামাজ পড়ুন"
        )
        private const val AMAL_FRIDAY = "সূরা আল-কাহফ তিলাওয়াত করুন"


        fun refreshAll(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, Salat3Widget::class.java))
            if (ids.isNotEmpty()) refresh(app, mgr, ids)
        }

        private fun refresh(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val zone = try {
                ZoneId.of(PrayerTimes.getTzId(ctx))
            } catch (e: Exception) {
                ZoneId.of(PrayerTimes.DEFAULT_TZ_ID)
            }
            val now = ZonedDateTime.now(zone)
            val today = now.toLocalDate()
            val start = today.atStartOfDay(zone)

            val todayMin = PrayerTimes.minutes(ctx, today)
            val tomorrowMin = PrayerTimes.minutes(ctx, today.plusDays(1))
            val shownTimes = Array(SHOWN.size) { start.plusMinutes(todayMin[SHOWN[it]].toLong()) }
            val nextFajr = today.plusDays(1).atStartOfDay(zone)
                .plusMinutes(tomorrowMin[SHOWN[0]].toLong())

            // পরবর্তী ওয়াক্ত কোনটি (সব শেষ হলে আগামীকালের ফজর)
            var nextIdx = 0
            var nextTime = nextFajr
            for (i in SHOWN.indices) {
                if (now.isBefore(shownTimes[i])) {
                    nextIdx = i
                    nextTime = shownTimes[i]
                    break
                }
            }

            // চলমান ওয়াক্ত: যেটার সময় পার হয়েছে তার মধ্যে শেষটি (ফজরের আগে হলে আগের রাতের ইশা)
            var current = SHOWN.size - 1
            for (i in SHOWN.indices) if (!now.isBefore(shownTimes[i])) current = i

            val v = RemoteViews(ctx.packageName, R.layout.widget_salat3)

            val dow = now.dayOfWeek.value % 7
            v.setTextViewText(R.id.s3_weekday, WEEK[dow])
            v.setTextViewText(
                R.id.s3_gdate,
                ordinal(today.dayOfMonth) + " " + GM[today.monthValue - 1] + ", " + bn(today.year)
            )
            val bd = CalendarWidget.toBengali(
                java.util.GregorianCalendar(today.year, today.monthValue - 1, today.dayOfMonth)
            )
            v.setTextViewText(R.id.s3_bdate, bn(bd[2]) + " " + BM[bd[1]] + ", " + bn(bd[0]))
            val h = HijrahDate.from(today)
            v.setTextViewText(
                R.id.s3_hijri,
                ordinal(h.get(ChronoField.DAY_OF_MONTH)) + " " +
                    HM[h.get(ChronoField.MONTH_OF_YEAR) - 1] + ",\n" +
                    bn(h.get(ChronoField.YEAR)) + " হিজরী"
            )
            val cn = country(ctx)
            v.setTextViewText(R.id.s3_city, PrayerTimes.getCity(ctx) + (if (cn.isEmpty()) "" else ", $cn"))

            // আজকের তাপমাত্রা (সর্বশেষ সংরক্ষিত মান; নেই বা পুরনো হলে লুকানো)
            val temp = Salat2Widget.cachedTemp(ctx)
            if (temp != null) {
                v.setTextViewText(R.id.s3_temp, bn(temp) + "° সেলসিয়াস")
                v.setViewVisibility(R.id.s3_temp, View.VISIBLE)
            } else {
                v.setViewVisibility(R.id.s3_temp, View.GONE)
            }

            val amal = if (dow == 5) AMAL_FRIDAY else AMAL[today.dayOfYear % AMAL.size]
            v.setTextViewText(R.id.s3_amal, amal)

            for (i in SHOWN.indices) {
                val m = todayMin[SHOWN[i]]
                v.setTextViewText(IDS_NAME[i], NAMES[i])
                v.setTextViewText(IDS_TIME[i], clock(m))
                v.setTextViewText(IDS_AMPM[i], if (m < 720) "পূর্বাহ্ণ" else "অপরাহ্ণ")
                val isCurrent = i == current
                val isNext = i == nextIdx && !isCurrent
                v.setInt(
                    IDS_BOX[i], "setBackgroundResource",
                    when {
                        isCurrent -> R.drawable.s3_cell_current
                        isNext -> R.drawable.s3_cell_next
                        else -> R.drawable.s3_cell
                    }
                )
                v.setTextColor(
                    IDS_NAME[i],
                    if (isCurrent) 0xFFF0A95A.toInt() else 0xFFF1F5F4.toInt()
                )
                if (isCurrent || isNext) {
                    v.setTextViewText(IDS_TAG[i], if (isCurrent) "চলমান" else "পরবর্তী")
                    v.setInt(
                        IDS_TAG[i], "setBackgroundResource",
                        if (isCurrent) R.drawable.s2_tag else R.drawable.s2_tag_next
                    )
                    v.setViewVisibility(IDS_TAG[i], View.VISIBLE)
                } else {
                    v.setViewVisibility(IDS_TAG[i], View.GONE)
                }
            }

            val open = PendingIntent.getActivity(
                ctx, 8, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.s3_root, open)

            // শহরের নামে চাপলে লোকেশন রিকোয়েস্ট (নামাজ উইজেটের মতোই)
            val locPi = PendingIntent.getBroadcast(
                ctx, 9, Intent(ctx, PrayerWidget::class.java).setAction(PrayerWidget.ACTION_LOCATION),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.s3_city_box, locPi)

            for (id in ids) mgr.updateAppWidget(id, v)

            // পরের ওয়াক্তে বা মধ্যরাতে আবার আপডেট
            val midnight = today.plusDays(1).atStartOfDay(zone).plusSeconds(5)
            val trigger = if (nextTime.isBefore(midnight)) nextTime.plusSeconds(2) else midnight
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 10, Intent(ctx, Salat3Widget::class.java).setAction(ACTION_UPDATE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.toInstant().toEpochMilli(), pi)
        }

        // টাইমজোন আইডি থেকে দেশ (শুধু পরিচিত কয়েকটি; না মিললে বাংলাদেশ/সৌদি ডিফল্ট অনুযায়ী)
        private fun country(ctx: Context): String = when (PrayerTimes.getTzId(ctx)) {
            "Asia/Dhaka" -> "বাংলাদেশ"
            "Asia/Riyadh" -> "সৌদি আরব"
            "Asia/Kolkata", "Asia/Calcutta" -> "ভারত"
            "Asia/Karachi" -> "পাকিস্তান"
            "Asia/Dubai" -> "সংযুক্ত আরব আমিরাত"
            "Asia/Kuala_Lumpur" -> "মালয়েশিয়া"
            "Asia/Qatar" -> "কাতার"
            "Asia/Kuwait" -> "কুয়েত"
            "Asia/Muscat" -> "ওমান"
            else -> ""
        }

        private fun bn(n: Int): String = CalendarWidget.bnNum(n)

        /** বাংলা তারিখের ক্রমবাচক রূপ: ১লা, ২রা, ৩রা, ৪ঠা, ৫ই … ১৯শে … */
        private fun ordinal(d: Int): String = bn(d) + when (d) {
            1 -> "লা"
            2, 3 -> "রা"
            4 -> "ঠা"
            in 5..18 -> "ই"
            else -> "শে"
        }

        private fun clock(totalMin: Int): String {
            val hh = (totalMin / 60) % 12
            val h12 = if (hh == 0) 12 else hh
            val mm = totalMin % 60
            return bn(h12) + ":" + (if (mm < 10) "০" else "") + bn(mm)
        }
    }
}
