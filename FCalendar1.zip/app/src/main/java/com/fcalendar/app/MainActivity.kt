package com.fcalendar.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var loadedDay = -1
    private val locHandler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            textZoom = 100
        }
        web.addJavascriptInterface(WidgetBridge(applicationContext, this), "FCalWidget")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                startActivity(Intent(Intent.ACTION_VIEW, u))
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        loadedDay = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)

        if (intent?.getBooleanExtra("request_location", false) == true) {
            requestLocation()
        }
        // নামাজের নোটিফিকেশন চালু থাকলে পরের ওয়াক্তের অ্যালার্ম নিশ্চিত করি
        PrayerNotifier.schedule(this)
        // নোটিফিকেশন প্যানেলের স্থায়ী নামাজের সময়সূচি
        requestNotifPermission()
        PrayerBar.start(this)
    }

    /** Android 13+: নোটিফিকেশন দেখানোর অনুমতি চায় */
    fun requestNotifPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("request_location", false)) {
            requestLocation()
        }
    }

    override fun onResume() {
        super.onResume()
        val d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        if (loadedDay != -1 && d != loadedDay) {
            loadedDay = d
            web.reload()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
                REQ_LOC
            )
            return
        }
        fetchLocation()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_NOTIF) {
            val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
            if (!ok) Toast.makeText(this, "নোটিফিকেশনের অনুমতি না দিলে ওয়াক্তের নোটিফিকেশন আসবে না", Toast.LENGTH_LONG).show()
            if (ok) PrayerBar.start(this)
            web.evaluateJavascript("window.onNotifPermission && window.onNotifPermission($ok)", null)
            return
        }
        if (code == REQ_LOC && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocation()
        } else {
            Toast.makeText(this, "লোকেশন অনুমতি দিন · Allow location", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
        var best: Location? = null
        for (p in providers) {
            try {
                if (!lm.isProviderEnabled(p)) continue
                val last = lm.getLastKnownLocation(p)
                if (last != null && (best == null || last.accuracy < best.accuracy)) best = last
            } catch (_: Exception) {}
        }
        if (best != null) {
            applyLocation(best)
            return
        }
        Toast.makeText(this, "লোকেশন খুঁজছি…", Toast.LENGTH_SHORT).show()
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                lm.removeUpdates(this)
                applyLocation(loc)
            }
            @Deprecated("Deprecated")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, listener, Looper.getMainLooper())
            locHandler.postDelayed({
                try { lm.removeUpdates(listener) } catch (_: Exception) {}
            }, 15000)
        } catch (e: Exception) {
            Toast.makeText(this, "লোকেশন পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyLocation(loc: Location) {
        val lat = loc.latitude
        val lng = loc.longitude
        val tz = TimeZone.getDefault()
        val tzHours = tz.rawOffset / 3600000.0 + tz.dstSavings / 3600000.0
        val tzId = tz.id
        Executors.newSingleThreadExecutor().execute {
            var city = String.format(Locale.US, "%.2f, %.2f", lat, lng)
            try {
                if (Geocoder.isPresent()) {
                    val geo = Geocoder(this, Locale("bn"))
                    @Suppress("DEPRECATION")
                    val list = geo.getFromLocation(lat, lng, 1)
                    if (!list.isNullOrEmpty()) {
                        val a = list[0]
                        city = a.locality ?: a.subAdminArea ?: a.adminArea ?: city
                    }
                }
            } catch (_: Exception) {}
            locHandler.post {
                PrayerTimes.setLocation(this, city, lat, lng, tzHours, tzId)
                Toast.makeText(this, "লোকেশন: $city", Toast.LENGTH_SHORT).show()
                try {
                    web.evaluateJavascript(
                        "window.onLocationUpdated && window.onLocationUpdated(" +
                            JSONObjectCompat(city, lat, lng) + ")", null
                    )
                } catch (_: Exception) {}
            }
        }
    }

    private fun JSONObjectCompat(city: String, lat: Double, lng: Double): String {
        val c = city.replace("\\", "\\\\").replace("\"", "\\\"")
        return "{\"city\":\"$c\",\"lat\":$lat,\"lng\":$lng}"
    }

    companion object {
        private const val REQ_LOC = 1001
        private const val REQ_NOTIF = 1002
    }
}

/** সেটিংসের JS থেকে উইজেট/সালাত সেটিংস */
class WidgetBridge(
    private val ctx: android.content.Context,
    private val activity: MainActivity?
) {
    @JavascriptInterface
    fun getColor(): String = WidgetColors.get(ctx)

    @JavascriptInterface
    fun setColor(id: String) {
        WidgetColors.set(ctx, id)
    }

    @JavascriptInterface
    fun getMadhhab(): String = PrayerTimes.getMadhhab(ctx).id

    @JavascriptInterface
    fun setMadhhab(id: String) {
        PrayerTimes.setMadhhab(ctx, id)
    }

    @JavascriptInterface
    fun getMethod(): String = PrayerTimes.getMethod(ctx).id

    @JavascriptInterface
    fun setMethod(id: String) {
        PrayerTimes.setMethod(ctx, id)
    }

    @JavascriptInterface
    fun getMethodsJson(): String {
        return PrayerTimes.METHODS.joinToString(",", "[", "]") {
            "{\"id\":\"${it.id}\",\"bn\":\"${it.nameBn}\",\"en\":\"${it.nameEn}\"}"
        }
    }

    @JavascriptInterface
    fun getMadhhabsJson(): String {
        return PrayerTimes.MADHHABS.joinToString(",", "[", "]") {
            "{\"id\":\"${it.id}\",\"bn\":\"${it.nameBn}\",\"en\":\"${it.nameEn}\"}"
        }
    }

    @JavascriptInterface
    fun getCity(): String = PrayerTimes.getCity(ctx)

    @JavascriptInterface
    fun requestLocation() {
        activity?.runOnUiThread { activity.requestLocation() }
    }

    @JavascriptInterface
    fun getPrayerBg(): String = PrayerTimes.getPrayerBg(ctx)

    @JavascriptInterface
    fun setPrayerBg(id: String) {
        PrayerTimes.setPrayerBg(ctx, id)
    }

    // ---- ম্যানুয়াল সময় সঠিককরণ ----
    @JavascriptInterface
    fun getManualOffsets(): String = PrayerTimes.getOffsets(ctx).joinToString(",")

    @JavascriptInterface
    fun setManualOffsets(csv: String) {
        val v = csv.split(",").map { it.trim().toIntOrNull() ?: 0 }.toIntArray()
        PrayerTimes.setOffsets(ctx, v)
    }

    /** আজকের হিসাব করা সময় (সংশোধন ছাড়া), মিনিটে: "fajr,dhuhr,asr,maghrib,isha" */
    @JavascriptInterface
    fun getBasePrayerMinutes(): String {
        val zone = try { java.time.ZoneId.of(PrayerTimes.getTzId(ctx)) } catch (e: Exception) { java.time.ZoneId.of(PrayerTimes.DEFAULT_TZ_ID) }
        return PrayerTimes.baseMinutes(ctx, java.time.LocalDate.now(zone)).joinToString(",")
    }

    // ---- নামাজের নোটিফিকেশন ----
    @JavascriptInterface
    fun getNotifyEnabled(): Boolean = PrayerNotifier.isEnabled(ctx)

    @JavascriptInterface
    fun setNotifyEnabled(on: Boolean) {
        PrayerNotifier.setEnabled(ctx, on)
        if (on) activity?.runOnUiThread { activity.requestNotifPermission() }
    }

    /** ফোনের সেটিংসে/অনুমতিতে নোটিফিকেশন চালু আছে কিনা */
    // ---- নোটিফিকেশন প্যানেলের স্থায়ী নামাজের চার্ট ----
    @JavascriptInterface
    fun getBarEnabled(): Boolean = PrayerBar.isEnabled(ctx)

    @JavascriptInterface
    fun setBarEnabled(on: Boolean) {
        PrayerBar.setEnabled(ctx, on)
        if (on) activity?.runOnUiThread { activity.requestNotifPermission() }
    }

    /** ফোনের সেটিংসে/অনুমতিতে নোটিফিকেশন চালু আছে কিনা */
    @JavascriptInterface
    fun getNotifyAllowed(): Boolean = PrayerNotifier.notificationsAllowed(ctx)

    @JavascriptInterface
    fun getNotifySound(): String = PrayerNotifier.getSoundId(ctx)

    @JavascriptInterface
    fun setNotifySound(id: String) {
        PrayerNotifier.setSoundId(ctx, id)
    }

    @JavascriptInterface
    fun getSoundsJson(): String {
        return PrayerNotifier.SOUNDS.joinToString(",", "[", "]") {
            "{\"id\":\"${it.id}\",\"bn\":\"${it.bn}\",\"en\":\"${it.en}\"}"
        }
    }

    @JavascriptInterface
    fun previewSound(id: String) {
        Handler(Looper.getMainLooper()).post { PrayerNotifier.preview(ctx, id) }
    }

    @JavascriptInterface
    fun stopPreview() {
        Handler(Looper.getMainLooper()).post { PrayerNotifier.stopPreview() }
    }

    @JavascriptInterface
    fun testNotify() {
        PrayerNotifier.test(ctx)
    }

    @JavascriptInterface
    fun getCountColor(): String = PrayerTimes.getCountColor(ctx)

    @JavascriptInterface
    fun setCountColor(id: String) {
        PrayerTimes.setCountColor(ctx, id)
    }
}
