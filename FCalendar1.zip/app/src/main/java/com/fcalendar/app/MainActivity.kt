package com.fcalendar.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var loadedDay = -1

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true   // থিম, ভাষা, জন্মতারিখ সেভ থাকার জন্য
            allowFileAccess = true
            textZoom = 100
        }
        web.addJavascriptInterface(WidgetBridge(applicationContext), "FCalWidget")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                startActivity(Intent(Intent.ACTION_VIEW, u))
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")
        loadedDay = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    }

    override fun onResume() {
        super.onResume()
        // দিন বদলে গেলে আজকের তারিখ ঠিক রাখতে পেজ রিলোড
        val d = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        if (loadedDay != -1 && d != loadedDay) {
            loadedDay = d
            web.reload()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

/** সেটিংসের JS থেকে উইজেটের রঙ পড়া/বদলানো */
class WidgetBridge(private val ctx: android.content.Context) {
    @JavascriptInterface
    fun getColor(): String = WidgetColors.get(ctx)

    @JavascriptInterface
    fun setColor(id: String) {
        WidgetColors.set(ctx, id)
    }
}
