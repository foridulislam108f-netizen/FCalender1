package com.fcalendar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** প্রতি ৩০ মিনিটে (এবং বুটের পর) লোকেশন, নামাজের শহর ও তাপমাত্রা আপডেট করে */
class TempReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!Salat2Widget.hasTempWidgets(ctx)) return
        val app = ctx.applicationContext
        val pr = goAsync()
        Thread {
            try { LocationSync.syncBlocking(app) } catch (_: Exception) {}
            Salat2Widget.fetchTempIfStale(app, pr, force = true)
        }.start()
    }
}
