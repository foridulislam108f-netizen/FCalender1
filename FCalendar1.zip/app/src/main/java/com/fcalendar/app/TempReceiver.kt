package com.fcalendar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** প্রতি ৩০ মিনিটে (এবং বুটের পর) তাপমাত্রা আপডেট করে */
class TempReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!Salat2Widget.hasTempWidgets(ctx)) return
        Salat2Widget.fetchTempIfStale(ctx, goAsync(), force = true)
    }
}
