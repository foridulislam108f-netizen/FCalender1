package com.fcalendar.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context

/** উইজেটের রঙের তালিকা + সেভ করা রঙ পড়া/লেখা */
object WidgetColors {
    private const val PREFS = "widget_prefs"
    private const val KEY = "color"
    const val DEFAULT = "green"

    /** id -> উইজেট ব্যাকগ্রাউন্ড ড্রয়েবল (id গুলো index.html এর তালিকার সাথে মিল থাকতে হবে) */
    val BACKGROUNDS: Map<String, Int> = linkedMapOf(
        "green" to R.drawable.widget_bg_green,
        "blue" to R.drawable.widget_bg_blue,
        "gray" to R.drawable.widget_bg_gray,
        "purple" to R.drawable.widget_bg_purple,
        "orange" to R.drawable.widget_bg_orange,
        "red" to R.drawable.widget_bg_red,
        "teal" to R.drawable.widget_bg_teal,
        "pink" to R.drawable.widget_bg_pink,
        "black" to R.drawable.widget_bg_black
    )

    fun get(ctx: Context): String {
        val c = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, DEFAULT) ?: DEFAULT
        return if (BACKGROUNDS.containsKey(c)) c else DEFAULT
    }

    fun background(ctx: Context): Int = BACKGROUNDS[get(ctx)] ?: R.drawable.widget_bg_green

    fun set(ctx: Context, id: String) {
        if (!BACKGROUNDS.containsKey(id)) return
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, id).apply()
        refreshAll(ctx)
    }

    /** হোম স্ক্রিনের সব উইজেট এখনই আপডেট করে */
    fun refreshAll(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val ids = mgr.getAppWidgetIds(ComponentName(app, CalendarWidget::class.java))
        if (ids.isNotEmpty()) CalendarWidget.update(app, mgr, ids)
    }
}
