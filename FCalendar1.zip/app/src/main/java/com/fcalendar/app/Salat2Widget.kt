package com.fcalendar.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.content.BroadcastReceiver
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/** "সালাত ২" উইজেট (৪x৩): তারিখ, হিজরি তারিখ ও পাঁচ ওয়াক্ত নামাজের সময়সূচী */
class Salat2Widget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        refresh(ctx, mgr, ids)
        fetchTempIfStale(ctx, goAsync())
        UpdateChecker.checkIfDue(ctx)
    }

    override fun onEnabled(ctx: Context) {
        refreshAll(ctx)
        fetchTempIfStale(ctx)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_UPDATE,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED -> {
                refreshAll(ctx)
                fetchTempIfStale(ctx, goAsync())
            }
        }
    }

    companion object {
        const val ACTION_UPDATE = "com.fcalendar.app.SALAT2_UPDATE"

        // পাঁচ ওয়াক্ত: PrayerTimes-এর সূচক (০=ফজর, ১=জোহর, ২=আসর, ৩=মাগরিব, ৪=ইশা)
        private val SHOWN = intArrayOf(0, 1, 2, 3, 4)
        private val NAMES = arrayOf("ফজর", "জোহর", "আসর", "মাগরিব", "ইশা")

        private val IDS_BOX = intArrayOf(R.id.s2_box0, R.id.s2_box1, R.id.s2_box2, R.id.s2_box3, R.id.s2_box4)
        private val IDS_NAME = intArrayOf(R.id.s2_name0, R.id.s2_name1, R.id.s2_name2, R.id.s2_name3, R.id.s2_name4)
        private val IDS_TIME = intArrayOf(R.id.s2_time0, R.id.s2_time1, R.id.s2_time2, R.id.s2_time3, R.id.s2_time4)
        private val IDS_AMPM = intArrayOf(R.id.s2_ampm0, R.id.s2_ampm1, R.id.s2_ampm2, R.id.s2_ampm3, R.id.s2_ampm4)
        private val IDS_TAG = intArrayOf(R.id.s2_tag0, R.id.s2_tag1, R.id.s2_tag2, R.id.s2_tag3, R.id.s2_tag4)

        private val WEEK = arrayOf(
            "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
        )
        private val BM = arrayOf(
            "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
            "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
        )
        private val GM = arrayOf(
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        )
        private val HM = arrayOf(
            "মুহাররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি", "জমাদিউল আউয়াল", "জমাদিউস সানি",
            "রজব", "শাবান", "রমজান", "শাওয়াল", "জিলকদ", "জিলহজ"
        )

        // প্রতিদিন একটি করে আমল (দিনের ক্রম অনুযায়ী ঘুরে ঘুরে আসে)
        private val AMAL = arrayOf(
            "সূরা আল-ফাতিহা তিলাওয়াত করুন",
            "সূরা ইখলাস তিলাওয়াত করুন",
            "আয়াতুল কুরসি পড়ুন",
            "ইস্তিগফার পড়ুন",
            "দরূদ শরীফ পড়ুন",
            "সকাল-সন্ধ্যার যিকির করুন",
            "কাউকে সালাম দিন",
            "ছোট কিছু দান করুন",
            "সূরা আল-মুলক তিলাওয়াত করুন",
            "চাশতের নামাজ পড়ুন"
        )
        private const val AMAL_FRIDAY = "সূরা আল-কাহফ তিলাওয়াত করুন"


        // ---------- তাপমাত্রা (Open-Meteo, কোনো কী লাগে না) ----------
        private const val TP_PREFS = "salat2_weather"
        private const val TP_VAL = "temp_c"
        private const val TP_TIME = "temp_time"
        private const val TP_LAT = "temp_lat"
        private const val TP_LNG = "temp_lng"
        private const val TP_FRESH_MS = 30 * 60 * 1000L
        private const val TP_MAX_AGE_MS = 6 * 60 * 60 * 1000L

        private fun cachedTemp(ctx: Context): Int? {
            val p = ctx.getSharedPreferences(TP_PREFS, Context.MODE_PRIVATE)
            if (!p.contains(TP_VAL)) return null
            if (System.currentTimeMillis() - p.getLong(TP_TIME, 0L) > TP_MAX_AGE_MS) return null
            return p.getInt(TP_VAL, 0)
        }

        /** তাপমাত্রা পুরনো (৩০ মিনিটের বেশি) বা লোকেশন বদলালে ব্যাকগ্রাউন্ডে নতুন করে আনে */
        fun fetchTempIfStale(ctx: Context, pr: BroadcastReceiver.PendingResult? = null) {
            val app = ctx.applicationContext
            val p = app.getSharedPreferences(TP_PREFS, Context.MODE_PRIVATE)
            val lat = PrayerTimes.getLat(app)
            val lng = PrayerTimes.getLng(app)
            val moved = Math.abs(p.getFloat(TP_LAT, 999f) - lat.toFloat()) > 0.05f ||
                Math.abs(p.getFloat(TP_LNG, 999f) - lng.toFloat()) > 0.05f
            val fresh = System.currentTimeMillis() - p.getLong(TP_TIME, 0L) < TP_FRESH_MS
            if (fresh && !moved) { pr?.finish(); return }
            Thread {
                try {
                    val url = URL(
                        "https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                            "&longitude=" + lng + "&current=temperature_2m&timezone=auto"
                    )
                    val c = url.openConnection() as HttpURLConnection
                    c.connectTimeout = 8000
                    c.readTimeout = 8000
                    val body = c.inputStream.bufferedReader().use { it.readText() }
                    c.disconnect()
                    val t = org.json.JSONObject(body).getJSONObject("current").getDouble("temperature_2m")
                    p.edit()
                        .putInt(TP_VAL, Math.round(t).toInt())
                        .putLong(TP_TIME, System.currentTimeMillis())
                        .putFloat(TP_LAT, lat.toFloat())
                        .putFloat(TP_LNG, lng.toFloat())
                        .apply()
                    refreshAll(app)
                } catch (e: Exception) {
                    // নেট না থাকলে আগের মানই থাকবে
                } finally {
                    pr?.finish()
                }
            }.start()
        }

        fun refreshAll(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, Salat2Widget::class.java))
            if (ids.isNotEmpty()) refresh(app, mgr, ids)
        }

        private fun refresh(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val zone = try {
                ZoneId.of(PrayerTimes.getTzId(ctx))
            } catch (e: Exception) {
                ZoneId.of(PrayerTimes.DEFAULT_TZ_ID)
            }
            val now = ZonedDateTime.now(zone)
            val today = now.toLocalDate()
            val start = today.atStartOfDay(zone)

            val todayMin = PrayerTimes.minutes(ctx, today)
            val tomorrowMin = PrayerTimes.minutes(ctx, today.plusDays(1))
            val shownTimes = Array(SHOWN.size) { start.plusMinutes(todayMin[SHOWN[it]].toLong()) }
            val nextFajr = today.plusDays(1).atStartOfDay(zone)
                .plusMinutes(tomorrowMin[SHOWN[0]].toLong())

            // পরবর্তী ওয়াক্ত কোনটি (সব শেষ হলে আগামীকালের ফজর)
            var nextIdx = 0
            var nextTime = nextFajr
            for (i in SHOWN.indices) {
                if (now.isBefore(shownTimes[i])) {
                    nextIdx = i
                    nextTime = shownTimes[i]
                    break
                }
            }

            // চলমান ওয়াক্ত: যেটার সময় পার হয়েছে তার মধ্যে শেষটি (ফজরের আগে হলে আগের রাতের ইশা)
            var current = SHOWN.size - 1
            for (i in SHOWN.indices) if (!now.isBefore(shownTimes[i])) current = i

            val v = RemoteViews(ctx.packageName, R.layout.widget_salat2)

            val dow = now.dayOfWeek.value % 7
            v.setTextViewText(R.id.s2_weekday, WEEK[dow])
            v.setTextViewText(
                R.id.s2_gdate,
                ordinal(today.dayOfMonth) + " " + GM[today.monthValue - 1] + ", " + bn(today.year)
            )
            val bd = CalendarWidget.toBengali(
                java.util.GregorianCalendar(today.year, today.monthValue - 1, today.dayOfMonth)
            )
            v.setTextViewText(R.id.s2_bdate, bn(bd[2]) + " " + BM[bd[1]] + ", " + bn(bd[0]))
            val h = HijrahDate.from(today)
            v.setTextViewText(
                R.id.s2_hijri,
                ordinal(h.get(ChronoField.DAY_OF_MONTH)) + " " +
                    HM[h.get(ChronoField.MONTH_OF_YEAR) - 1] + ",\n" +
                    bn(h.get(ChronoField.YEAR)) + " হিজরী"
            )
            val cn = country(ctx)
            v.setTextViewText(R.id.s2_city, PrayerTimes.getCity(ctx) + (if (cn.isEmpty()) "" else ", $cn"))

            // আজকের তাপমাত্রা (সর্বশেষ সংরক্ষিত মান; নেই বা পুরনো হলে লুকানো)
            val temp = cachedTemp(ctx)
            if (temp != null) {
                v.setTextViewText(R.id.s2_temp, bn(temp) + "° সেলসিয়াস")
                v.setViewVisibility(R.id.s2_temp_row, View.VISIBLE)
            } else {
                v.setViewVisibility(R.id.s2_temp_row, View.GONE)
            }

            val amal = if (dow == 5) AMAL_FRIDAY else AMAL[today.dayOfYear % AMAL.size]
            v.setTextViewText(R.id.s2_amal, amal)

            for (i in SHOWN.indices) {
                val m = todayMin[SHOWN[i]]
                v.setTextViewText(IDS_NAME[i], NAMES[i])
                v.setTextViewText(IDS_TIME[i], clock(m))
                v.setTextViewText(IDS_AMPM[i], if (m < 720) "পূর্বাহ্ণ" else "অপরাহ্ণ")
                val isCurrent = i == current
                val isNext = i == nextIdx && !isCurrent
                v.setInt(
                    IDS_BOX[i], "setBackgroundResource",
                    when {
                        isCurrent -> R.drawable.s2_cell_current
                        isNext -> R.drawable.s2_cell_next
                        else -> R.drawable.s2_cell
                    }
                )
                v.setTextColor(
                    IDS_NAME[i],
                    if (isCurrent) 0xFFF0A95A.toInt() else 0xFFF1F5F4.toInt()
                )
                if (isCurrent || isNext) {
                    v.setTextViewText(IDS_TAG[i], if (isCurrent) "চলমান" else "পরবর্তী")
                    v.setInt(
                        IDS_TAG[i], "setBackgroundResource",
                        if (isCurrent) R.drawable.s2_tag else R.drawable.s2_tag_next
                    )
                    v.setViewVisibility(IDS_TAG[i], View.VISIBLE)
                } else {
                    v.setViewVisibility(IDS_TAG[i], View.GONE)
                }
            }

            val open = PendingIntent.getActivity(
                ctx, 5, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.s2_root, open)

            // শহরের নামে চাপলে লোকেশন রিকোয়েস্ট (নামাজ উইজেটের মতোই)
            val locPi = PendingIntent.getBroadcast(
                ctx, 6, Intent(ctx, PrayerWidget::class.java).setAction(PrayerWidget.ACTION_LOCATION),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.s2_city_box, locPi)

            for (id in ids) mgr.updateAppWidget(id, v)

            // পরের ওয়াক্তে বা মধ্যরাতে আবার আপডেট
            val midnight = today.plusDays(1).atStartOfDay(zone).plusSeconds(5)
            val trigger = if (nextTime.isBefore(midnight)) nextTime.plusSeconds(2) else midnight
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 7, Intent(ctx, Salat2Widget::class.java).setAction(ACTION_UPDATE),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger.toInstant().toEpochMilli(), pi)
        }

        // টাইমজোন আইডি থেকে দেশ (শুধু পরিচিত কয়েকটি; না মিললে বাংলাদেশ/সৌদি ডিফল্ট অনুযায়ী)
        private fun country(ctx: Context): String = when (PrayerTimes.getTzId(ctx)) {
            "Asia/Dhaka" -> "বাংলাদেশ"
            "Asia/Riyadh" -> "সৌদি আরব"
            "Asia/Kolkata", "Asia/Calcutta" -> "ভারত"
            "Asia/Karachi" -> "পাকিস্তান"
            "Asia/Dubai" -> "সংযুক্ত আরব আমিরাত"
            "Asia/Kuala_Lumpur" -> "মালয়েশিয়া"
            "Asia/Qatar" -> "কাতার"
            "Asia/Kuwait" -> "কুয়েত"
            "Asia/Muscat" -> "ওমান"
            else -> ""
        }

        private fun bn(n: Int): String = CalendarWidget.bnNum(n)

        /** বাংলা তারিখের ক্রমবাচক রূপ: ১লা, ২রা, ৩রা, ৪ঠা, ৫ই … ১৯শে … */
        private fun ordinal(d: Int): String = bn(d) + when (d) {
            1 -> "লা"
            2, 3 -> "রা"
            4 -> "ঠা"
            in 5..18 -> "ই"
            else -> "শে"
        }

        private fun clock(totalMin: Int): String {
            val hh = (totalMin / 60) % 12
            val h12 = if (hh == 0) 12 else hh
            val mm = totalMin % 60
            return bn(h12) + ":" + (if (mm < 10) "০" else "") + bn(mm)
        }
    }
}
