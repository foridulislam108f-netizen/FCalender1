package com.fcalendar.app

import java.time.LocalDate
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * অফলাইন নামাজের সময় (উম্মুল কুরা পদ্ধতি: ফজর ১৮.৫°, ইশা = মাগরিবের ৯০ মিনিট পর, আসর = ১ গুণ ছায়া)।
 * রিয়াদের জন্য ঠিক করা। শহর বদলাতে নিচের CITY / LAT / LNG / TZ_HOURS বদলান।
 */
object PrayerTimes {
    const val CITY = "রিয়াদ"
    const val LAT = 24.7136
    const val LNG = 46.6753
    const val TZ_HOURS = 3.0
    const val TZ_ID = "Asia/Riyadh"

    /** দিনের শুরু থেকে মিনিট: [ফজর, যোহর, আসর, মাগরিব, ঈশা] */
    fun minutes(date: LocalDate): IntArray {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - LNG / (15.0 * 24.0)

        fun mid(t: Double): Double = (12.0 - sunPos(jd + t)[1]).mod(24.0)

        fun angleTime(angle: Double, t: Double, after: Boolean): Double {
            val decl = sunPos(jd + t)[0]
            val v = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(LAT))) /
                (cos(rad(decl)) * cos(rad(LAT)))
            val h = Math.toDegrees(acos(v.coerceIn(-1.0, 1.0))) / 15.0
            return mid(t) + if (after) h else -h
        }

        val adj = TZ_HOURS - LNG / 15.0
        val noon = mid(0.5)
        val fajr = angleTime(18.5, 5.0 / 24.0, false) + adj

        val declNoon = sunPos(jd + 0.5)[0]
        val asrAlt = atan(1.0 / (1.0 + tan(rad(Math.abs(LAT - declNoon)))))
        val vAsr = (sin(asrAlt) - sin(rad(declNoon)) * sin(rad(LAT))) /
            (cos(rad(declNoon)) * cos(rad(LAT)))
        val asr = noon + Math.toDegrees(acos(vAsr.coerceIn(-1.0, 1.0))) / 15.0 + adj

        val maghrib = angleTime(0.833, 18.0 / 24.0, true) + adj
        val isha = maghrib + 90.0 / 60.0
        val dhuhr = noon + adj

        return intArrayOf(
            Math.ceil(fajr * 60.0 - 1e-6).toInt(),          // ফজর: পরের মিনিটে
            floor(dhuhr * 60.0 - 0.01).toInt(),
            floor(asr * 60.0).toInt(),
            floor(maghrib * 60.0).toInt(),
            floor(isha * 60.0).toInt()
        )
    }

    private fun rad(x: Double) = Math.toRadians(x)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = y / 100
        val b = 2 - a + a / 4
        return (365.25 * (y + 4716)).toInt() + (30.6001 * (m + 1)).toInt() + d + b - 1524.5
    }

    /** [declination°, equationOfTime ঘণ্টা] */
    private fun sunPos(jd: Double): DoubleArray {
        val dd = jd - 2451545.0
        val g = (357.529 + 0.98560028 * dd).mod(360.0)
        val q = (280.459 + 0.98564736 * dd).mod(360.0)
        val l = (q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g))).mod(360.0)
        val e = 23.439 - 0.00000036 * dd
        val ra = Math.toDegrees(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        var eqt = q / 15.0 - ra.mod(24.0)
        if (eqt > 12) eqt -= 24
        if (eqt < -12) eqt += 24
        val decl = Math.toDegrees(asin(sin(rad(e)) * sin(rad(l))))
        return doubleArrayOf(decl, eqt)
    }
}
