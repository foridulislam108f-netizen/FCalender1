package com.fcalendar.app

import android.content.Context
import java.time.LocalDate
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * অফলাইন নামাজের সময়।
 * মাজহাব = আসরের ছায়া-গুণক (১ বা ২)
 * সময় গণনা = ফজর/ইশার কোণ বা নিয়ম
 */
object PrayerTimes {

    private const val PREFS = "prayer_prefs"
    private const val KEY_CITY = "city"
    private const val KEY_LAT = "lat"
    private const val KEY_LNG = "lng"
    private const val KEY_TZ = "tz_hours"
    private const val KEY_TZ_ID = "tz_id"
    private const val KEY_MADHHAB = "madhhab"
    private const val KEY_METHOD = "calc_method"
    private const val KEY_BG = "prayer_bg"
    private const val KEY_COUNT = "prayer_count_color"
    private const val KEY_OFFSETS = "manual_offsets"
    const val MAX_OFFSET = 120

    const val DEFAULT_CITY = "রিয়াদ"
    const val DEFAULT_LAT = 24.7136
    const val DEFAULT_LNG = 46.6753
    const val DEFAULT_TZ = 3.0
    const val DEFAULT_TZ_ID = "Asia/Riyadh"
    const val DEFAULT_MADHHAB = "hanafi"
    const val DEFAULT_METHOD = "umm_al_qura"

    data class Madhhab(val id: String, val nameBn: String, val nameEn: String, val asrFactor: Double)

    data class CalcMethod(
        val id: String,
        val nameBn: String,
        val nameEn: String,
        val fajrAngle: Double,
        val ishaMinutesAfterMaghrib: Double? = null,
        val ishaAngle: Double = 17.0
    )

    /** শুধু ৪ মাজহাব */
    val MADHHABS = listOf(
        Madhhab("hanafi", "হানাফি", "Hanafi", 2.0),
        Madhhab("shafii", "শাফেয়ী", "Shafi'i", 1.0),
        Madhhab("maliki", "মালিকি", "Maliki", 1.0),
        Madhhab("hanbali", "হাম্বলি", "Hanbali", 1.0)
    )

    /** সময় গণনার ৪ পদ্ধতি */
    val METHODS = listOf(
        CalcMethod("egypt", "মিশর", "Egypt", 19.5, ishaAngle = 17.5),
        CalcMethod("mwl", "মুসলিম ওয়ার্ল্ড লীগ", "Muslim World League", 18.0, ishaAngle = 17.0),
        CalcMethod("umm_al_qura", "উম্মুল কুরা", "Umm al-Qura", 18.5, ishaMinutesAfterMaghrib = 90.0),
        CalcMethod("isna", "আইএসএনএ", "ISNA", 15.0, ishaAngle = 15.0)
    )

    fun getMadhhab(ctx: Context): Madhhab {
        val id = prefs(ctx).getString(KEY_MADHHAB, DEFAULT_MADHHAB) ?: DEFAULT_MADHHAB
        return MADHHABS.find { it.id == id } ?: MADHHABS[0]
    }

    fun setMadhhab(ctx: Context, id: String) {
        if (MADHHABS.none { it.id == id }) return
        prefs(ctx).edit().putString(KEY_MADHHAB, id).apply()
        PrayerWidget.refreshAll(ctx)
        PrayerNotifier.schedule(ctx)
    }

    fun getMethod(ctx: Context): CalcMethod {
        val id = prefs(ctx).getString(KEY_METHOD, DEFAULT_METHOD) ?: DEFAULT_METHOD
        return METHODS.find { it.id == id } ?: METHODS[2]
    }

    fun setMethod(ctx: Context, id: String) {
        if (METHODS.none { it.id == id }) return
        prefs(ctx).edit().putString(KEY_METHOD, id).apply()
        PrayerWidget.refreshAll(ctx)
        PrayerNotifier.schedule(ctx)
    }

    fun getCity(ctx: Context): String =
        prefs(ctx).getString(KEY_CITY, DEFAULT_CITY) ?: DEFAULT_CITY

    fun getLat(ctx: Context): Double =
        prefs(ctx).getFloat(KEY_LAT, DEFAULT_LAT.toFloat()).toDouble()

    fun getLng(ctx: Context): Double =
        prefs(ctx).getFloat(KEY_LNG, DEFAULT_LNG.toFloat()).toDouble()

    fun getTzHours(ctx: Context): Double =
        prefs(ctx).getFloat(KEY_TZ, DEFAULT_TZ.toFloat()).toDouble()

    fun getTzId(ctx: Context): String =
        prefs(ctx).getString(KEY_TZ_ID, DEFAULT_TZ_ID) ?: DEFAULT_TZ_ID

    fun setLocation(ctx: Context, city: String, lat: Double, lng: Double, tzHours: Double, tzId: String) {
        prefs(ctx).edit()
            .putString(KEY_CITY, city)
            .putFloat(KEY_LAT, lat.toFloat())
            .putFloat(KEY_LNG, lng.toFloat())
            .putFloat(KEY_TZ, tzHours.toFloat())
            .putString(KEY_TZ_ID, tzId)
            .apply()
        PrayerWidget.refreshAll(ctx)
        PrayerNotifier.schedule(ctx)
    }

    fun getPrayerBg(ctx: Context): String =
        prefs(ctx).getString(KEY_BG, "default") ?: "default"

    fun setPrayerBg(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_BG, id).apply()
        PrayerWidget.refreshAll(ctx)
    }

    fun getCountColor(ctx: Context): String =
        prefs(ctx).getString(KEY_COUNT, "default") ?: "default"

    fun setCountColor(ctx: Context, id: String) {
        prefs(ctx).edit().putString(KEY_COUNT, id).apply()
        PrayerWidget.refreshAll(ctx)
    }

    /** ম্যানুয়াল সময় সঠিককরণ: ফজর, যোহর, আসর, মাগরিব, ঈশা (মিনিট, + / -) */
    fun getOffsets(ctx: Context): IntArray {
        val parts = (prefs(ctx).getString(KEY_OFFSETS, "") ?: "").split(",")
        return IntArray(5) { i ->
            (parts.getOrNull(i)?.trim()?.toIntOrNull() ?: 0).coerceIn(-MAX_OFFSET, MAX_OFFSET)
        }
    }

    fun setOffsets(ctx: Context, offsets: IntArray) {
        val v = IntArray(5) { (offsets.getOrNull(it) ?: 0).coerceIn(-MAX_OFFSET, MAX_OFFSET) }
        prefs(ctx).edit().putString(KEY_OFFSETS, v.joinToString(",")).apply()
        PrayerWidget.refreshAll(ctx)
        PrayerNotifier.schedule(ctx)
        PrayerBar.refresh(ctx)
    }

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** ম্যানুয়াল সংশোধনসহ আজকের সময় (মিনিট) */
    fun minutes(ctx: Context, date: LocalDate): IntArray {
        val base = baseMinutes(ctx, date)
        val off = getOffsets(ctx)
        return IntArray(5) { base[it] + off[it] }
    }

    /** ম্যানুয়াল সংশোধন ছাড়া হিসাব করা সময় */
    fun baseMinutes(ctx: Context, date: LocalDate): IntArray {
        return minutes(
            date,
            getLat(ctx),
            getLng(ctx),
            getTzHours(ctx),
            getMadhhab(ctx),
            getMethod(ctx)
        )
    }

    fun minutes(
        date: LocalDate,
        lat: Double = DEFAULT_LAT,
        lng: Double = DEFAULT_LNG,
        tzHours: Double = DEFAULT_TZ,
        madhhab: Madhhab = MADHHABS[0],
        method: CalcMethod = METHODS[2]
    ): IntArray {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)

        fun mid(t: Double): Double = (12.0 - sunPos(jd + t)[1]).mod(24.0)

        fun angleTime(angle: Double, t: Double, after: Boolean): Double {
            val decl = sunPos(jd + t)[0]
            val v = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) /
                (cos(rad(decl)) * cos(rad(lat)))
            val h = Math.toDegrees(acos(v.coerceIn(-1.0, 1.0))) / 15.0
            return mid(t) + if (after) h else -h
        }

        val adj = tzHours - lng / 15.0
        val noon = mid(0.5)
        val fajr = angleTime(method.fajrAngle, 5.0 / 24.0, false) + adj

        val declNoon = sunPos(jd + 0.5)[0]
        val asrAlt = atan(1.0 / (madhhab.asrFactor + tan(rad(Math.abs(lat - declNoon)))))
        val vAsr = (sin(asrAlt) - sin(rad(declNoon)) * sin(rad(lat))) /
            (cos(rad(declNoon)) * cos(rad(lat)))
        val asr = noon + Math.toDegrees(acos(vAsr.coerceIn(-1.0, 1.0))) / 15.0 + adj

        val maghrib = angleTime(0.833, 18.0 / 24.0, true) + adj
        val isha = if (method.ishaMinutesAfterMaghrib != null) {
            maghrib + method.ishaMinutesAfterMaghrib!! / 60.0
        } else {
            angleTime(method.ishaAngle, 18.0 / 24.0, true) + adj
        }
        val dhuhr = noon + adj

        return intArrayOf(
            Math.ceil(fajr * 60.0 - 1e-6).toInt(),
            floor(dhuhr * 60.0 - 0.01).toInt(),
            floor(asr * 60.0).toInt(),
            floor(maghrib * 60.0).toInt(),
            floor(isha * 60.0).toInt()
        )
    }

    private fun rad(x: Double) = Math.toRadians(x)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0
        var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = y / 100
        val b = 2 - a + a / 4
        return (365.25 * (y + 4716)).toInt() + (30.6001 * (m + 1)).toInt() + d + b - 1524.5
    }

    private fun sunPos(jd: Double): DoubleArray {
        val dd = jd - 2451545.0
        val g = (357.529 + 0.98560028 * dd).mod(360.0)
        val q = (280.459 + 0.98564736 * dd).mod(360.0)
        val l = (q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g))).mod(360.0)
        val e = 23.439 - 0.00000036 * dd
        val ra = Math.toDegrees(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0
        var eqt = q / 15.0 - ra.mod(24.0)
        if (eqt > 12) eqt -= 24
        if (eqt < -12) eqt += 24
        val decl = Math.toDegrees(asin(sin(rad(e)) * sin(rad(l))))
        return doubleArrayOf(decl, eqt)
    }
}
