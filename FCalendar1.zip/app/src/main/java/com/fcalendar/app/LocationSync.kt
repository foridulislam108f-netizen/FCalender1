package com.fcalendar.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** বর্তমান লোকেশন ধরে নামাজের শহর, টাইমজোন ও সময় নিজে থেকে বদলায় */
object LocationSync {

    private const val MIN_MOVE_METERS = 5000f

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun currentLocation(ctx: Context): Location? {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var fresh: Location? = null
        try {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                val latch = CountDownLatch(1)
                val cs = androidx.core.os.CancellationSignal()
                LocationManagerCompat.getCurrentLocation(
                    lm, LocationManager.NETWORK_PROVIDER, cs, ContextCompat.getMainExecutor(ctx)
                ) { l -> fresh = l; latch.countDown() }
                if (!latch.await(6, TimeUnit.SECONDS)) cs.cancel()
            }
        } catch (_: Exception) {}
        if (fresh != null) return fresh
        var best: Location? = null
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best!!.time) best = l
            } catch (_: Exception) {}
        }
        return best
    }

    /** ব্যাকগ্রাউন্ড থ্রেডে ডাকতে হবে। জায়গা ৫ কিমির বেশি বদলালে শহর ও সময় নতুন করে সেট করে */
    fun syncBlocking(context: Context, onChanged: ((String, Double, Double) -> Unit)? = null) {
        val ctx = context.applicationContext
        try {
            if (!hasPermission(ctx)) return
            val loc = currentLocation(ctx) ?: return
            val d = FloatArray(1)
            Location.distanceBetween(PrayerTimes.getLat(ctx), PrayerTimes.getLng(ctx), loc.latitude, loc.longitude, d)
            if (d[0] < MIN_MOVE_METERS) return

            var city = String.format(Locale.US, "%.2f, %.2f", loc.latitude, loc.longitude)
            if (Geocoder.isPresent()) {
                try {
                    @Suppress("DEPRECATION")
                    val list = Geocoder(ctx, Locale("bn")).getFromLocation(loc.latitude, loc.longitude, 1)
                    if (list.isNullOrEmpty()) return
                    val a = list[0]
                    city = a.locality ?: a.subAdminArea ?: a.adminArea ?: city
                } catch (_: Exception) {
                    return // নেট নেই: পরের বারে আবার চেষ্টা
                }
            }
            val tz = TimeZone.getDefault()
            val tzHours = tz.rawOffset / 3600000.0 + tz.dstSavings / 3600000.0
            PrayerTimes.setLocation(ctx, city, loc.latitude, loc.longitude, tzHours, tz.id)
            onChanged?.invoke(city, loc.latitude, loc.longitude)
        } catch (_: Exception) {}
    }
}
