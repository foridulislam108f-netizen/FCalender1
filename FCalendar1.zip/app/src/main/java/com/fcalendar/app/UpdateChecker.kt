package com.fcalendar.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHub-এর সর্বশেষ Release দেখে নতুন ভার্সন থাকলে নোটিফিকেশন দেয়।
 * নোটিফিকেশনে চাপলে ব্রাউজারে APK ডাউনলোড শুরু হয়।
 */
object UpdateChecker {

    private const val PREFS = "update_check"
    private const val KEY_LAST = "last_check"
    private const val KEY_NOTIFIED = "notified_code"
    private const val CHANNEL = "app_update"
    private const val NOTIF_ID = 9001
    private const val EVERY_MS = 3 * 60 * 60 * 1000L

    /** ৩ ঘণ্টার মধ্যে একবারের বেশি চেক করে না; ব্যাকগ্রাউন্ড থ্রেডে চলে */
    fun checkIfDue(ctx: Context, force: Boolean = false) {
        val app = ctx.applicationContext
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isEmpty()) return
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && now - p.getLong(KEY_LAST, 0L) < EVERY_MS) return
        p.edit().putLong(KEY_LAST, now).apply()
        Thread {
            try {
                val c = URL("https://api.github.com/repos/$repo/releases/latest")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val j = JSONObject(body)
                val tag = j.getString("tag_name")            // build-<রান নম্বর>
                val code = 100 + (tag.substringAfterLast('-').toIntOrNull() ?: return@Thread)
                if (code <= BuildConfig.VERSION_CODE) return@Thread
                if (p.getInt(KEY_NOTIFIED, 0) >= code) return@Thread
                var url = j.optString("html_url")
                val assets = j.optJSONArray("assets")
                if (assets != null && assets.length() > 0) {
                    url = assets.getJSONObject(0).optString("browser_download_url", url)
                }
                val name = j.optString("name", tag)
                if (notify(app, name, url)) p.edit().putInt(KEY_NOTIFIED, code).apply()
            } catch (e: Exception) {
                // নেট নেই বা রিলিজ নেই — পরের বার আবার চেক হবে
            }
        }.start()
    }

    private fun notify(ctx: Context, name: String, url: String): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "অ্যাপ আপডেট", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val pi = PendingIntent.getActivity(
            ctx, 91, Intent(Intent.ACTION_VIEW, Uri.parse(url)),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_prayer)
            .setContentTitle("নতুন আপডেট এসেছে")
            .setContentText("$name — ডাউনলোড করতে এখানে চাপুন")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_ID, n)
        return true
    }
}
